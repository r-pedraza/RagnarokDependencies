#import <Foundation/Foundation.h>

//! Project version number for POEditorParser.
FOUNDATION_EXPORT double POEditorParserVersionNumber;

//! Project version string for POEditorParser.
FOUNDATION_EXPORT const unsigned char POEditorParserVersionString[];